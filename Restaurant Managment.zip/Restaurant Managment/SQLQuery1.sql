﻿create table tables
(
tID int primary key identity,
tName varchar(15)
)